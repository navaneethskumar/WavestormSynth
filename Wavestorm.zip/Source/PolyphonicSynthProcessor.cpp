/*
  ==============================================================================

    PolyphonicSynthProcessor.cpp
    Created: 25 Oct 2023 6:04:34pm
    Author:  Navaneeth Suresh Kumar

  ==============================================================================
*/

#include "PolyphonicSynthProcessor.h"
#include "OscillatorClass.h"
#include <vector>
#include "JuceHeader.h"


void prepareToPlay(double sampleRate)
{
    
}
